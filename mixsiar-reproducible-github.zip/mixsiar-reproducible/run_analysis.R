# Run with Rscript --vanilla run_analysis.R prepare|test|normal|long [output_directory]
args <- commandArgs(trailingOnly = TRUE)
mode <- if(length(args)) args[1] else "prepare"
if(!mode %in% c("prepare", "test", "normal", "long")) stop("Mode must be prepare, test, normal, or long")
script_arg <- grep("^--file=", commandArgs(), value = TRUE)
project_root <- if(length(script_arg)) dirname(normalizePath(sub("^--file=", "", script_arg[1]), winslash="/")) else getwd()
if(length(script_arg) && basename(sub("^--file=", "", script_arg[1]))=="run_locked.R") project_root <- dirname(project_root)
setwd(project_root)
packs <- c("dplyr", "stringr", "readr", "purrr", "tidyr", "MixSIAR", "tibble")
missing <- packs[!vapply(packs, requireNamespace, logical(1), quietly=TRUE)]
if(length(missing)) stop("Install dependencies with Rscript scripts/install_dependencies.R. Missing: ", paste(missing, collapse=", "))
invisible(lapply(packs, library, character.only=TRUE))
options(scipen=999)
Sys.setlocale("LC_COLLATE", "C")
RNGkind("Mersenne-Twister", "Inversion", "Rejection")
input_file <- file.path(project_root, "data", "raw", "master_data.csv")
output <- if(length(args)>1) args[2] else file.path("results", mode)
dir.create(output, recursive=TRUE, showWarnings=FALSE)
dir_base <- normalizePath(output, winslash="/")
if(file.exists(file.path(dir_base, "logs", "run_log.csv"))) stop("Output already contains a run. Choose a new output directory.")
for(key in c("data", "mix", "src", "discr", "mod", "sum", "logs")) {
  subdir <- c(data="processed_data",mix="mix_files",src="source_files",discr="discrimination_files",mod="model_outputs",sum="summary_tables",logs="logs")[[key]]
  assign(paste0("dir_",key),file.path(dir_base,subdir))
  dir.create(file.path(dir_base,subdir),showWarnings=FALSE)
}
source("R/model_specs.R",encoding="UTF-8")
source("R/helpers.R",encoding="UTF-8")
source("R/prepare_data.R",encoding="UTF-8")
source("R/fit_models.R",encoding="UTF-8")
model_indices <- if(length(args)>2) as.integer(strsplit(args[3],",",fixed=TRUE)[[1]]) else seq_along(model_specs)
if(anyNA(model_indices) || any(!model_indices %in% seq_along(model_specs)) || anyDuplicated(model_indices)) stop("Invalid model index selection")
writeLines(capture.output(sessionInfo()),file.path(dir_logs,"session_info.txt"))
write_csv(tibble(file="data/raw/master_data.csv",md5=unname(tools::md5sum(input_file))),file.path(dir_logs,"input_checksum.csv"))
run_log <- list()
for(i in model_indices) {
  spec <- model_specs[[i]]
  id <- safe_name(spec$consumer)
  seed <- 20260911L + i
  message("Model ",i,"/",length(model_specs),": ",id," [",mode,"]")
  status <- tryCatch({
    mix_df <- create_mix_file(data_clean,spec$consumer)
    source_df <- create_fixed_sources(data_clean,spec$sources)
    mix_file <- file.path(dir_mix,paste0("mix_",id,".csv"))
    source_file <- file.path(dir_src,paste0("source_",id,".csv"))
    discr_file <- file.path(dir_discr,paste0("discr_",id,".csv"))
    write_csv(mix_df,mix_file)
    write_csv(source_df,source_file)
    write_csv(create_discrimination_file(source_df),discr_file)
    if(any(source_df$n<2)) stop("Each source needs at least two observations to estimate its SD")
    if(mode!="prepare") fit_model(id,mix_file,source_file,discr_file,source_df,mode,seed)
    tibble(Model=id,Mode=mode,Seed=seed,Status=if(mode=="prepare") "Prepared" else "Ran",Reason=NA_character_)
  },error=function(e) tibble(Model=id,Mode=mode,Seed=seed,Status="Error",Reason=conditionMessage(e)))
  run_log[[i]] <- status
  write_csv(bind_rows(run_log),file.path(dir_logs,"run_log.csv"))
  gc()
}
writeLines(capture.output(sessionInfo()),file.path(dir_logs,"session_info.txt"))
if(any(bind_rows(run_log)$Status=="Error")) stop("One or more models failed; see logs/run_log.csv")
message("Completed: ",dir_base)
